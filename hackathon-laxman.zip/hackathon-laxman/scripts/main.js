/*define(['modules/sample-module/main'], function() {

});*/

//define(['modules/sample-module/sample-module', 'modules/sample-module/sample-directive', 'modules/sample-module/sample-filter', 'modules/sample-module/sample-service', 'modules/sample-module/dashboard-controller',
    //'modules/sample-module/sample-controller', 'modules/sample-module/predix-asset-service', 'modules/sample-module/predix-user-service', 'modules/sample-module/predix-view-service', 'controllers/patients', 'controllers/hospitals'], function() {
define(['modules/sample-module/sample-module', 'modules/sample-module/sample-directive', 'modules/sample-module/sample-filter', 'modules/sample-module/sample-service', 'modules/sample-module/dashboard-controller',
    'modules/sample-module/sample-controller', 'modules/sample-module/predix-asset-service', 'modules/sample-module/predix-user-service', 'modules/sample-module/predix-view-service', 'controllers/dashboard', 'controllers/vizag','controllers/vijayawada','controllers/nizambad'], function() {

});
