'use strict';
define(['angular','modules/sample-module/sample-module'],function(angular, controllers){
	
	controllers.controller('VijayawadaCtrl',['$rootScope','$scope', function($rootScope, $scope){
		
		
	}]);
	
});