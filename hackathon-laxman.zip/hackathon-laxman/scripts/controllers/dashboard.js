'use strict';
define(['angular','modules/sample-module/sample-module'],function(angular, controllers){
	//Controller definition
	controllers.controller('DashboardCtrl',['$rootScope','$scope','$location',function($rootScope, $scope, $location){
	
		$scope.hyderabadLights = function(path){
			console.log(path);
			//alert('hyderabad lights');
			//$location.path('http://localhost:9000'+path);
			window.location = path;
			
		};
	}]);
});