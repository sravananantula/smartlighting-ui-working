'use strict';
define(['angular','modules/sample-module/sample-module'],function(angular, controllers){
	//Controller definition
	controllers.controller('NizambadCtrl',['$rootScope','$scope',function($rootScope, $scope){
		$scope.form={};
		
		
		
	}]);
});