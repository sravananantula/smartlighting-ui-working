define(['modules/sample-module/main'], function() {

});
