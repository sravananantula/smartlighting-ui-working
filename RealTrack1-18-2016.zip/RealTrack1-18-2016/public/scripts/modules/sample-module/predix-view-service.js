/*global define */
define(['angular', './sample-module'], function (angular, module) {
    'use strict';
    /**
    * PredixViewService is a sample angular service that integrates with Predix View Service API
    */
    module.factory('PredixViewService', ['$http', '$q', function ($http, $q) {
        return {
            getDecksByTags: function (tags) {
                var deferred = $q.defer();
                var baseUrl = '/sample-data/first.json';
                //var data =  [{"id":"1","title":"Overview","slug":"px-deck","cardOrder":null,"createTimeStamp":"2015-11-24T23:02:53.838Z","tags":[{"id":"1","value":"parent"}]},{"id":"3","title":"Datagrid View","slug":"px-deck","cardOrder":null,"createTimeStamp":"2015-11-24T23:02:53.838Z","tags":[{"id":"3","value":"parent"}]}];
               // var data = [{"id":"1","title":"Overview","slug":"px-deck","cardOrder":null,"createTimeStamp":"2015-11-24T23:02:53.838Z","tags":[{"id":"1","value":"parent"}]},{"id":"3","title":"Datagrid View","slug":"px-deck","cardOrder":null,"createTimeStamp":"2015-11-24T23:02:53.838Z","tags":[{"id":"3","value":"parent"}]}];
                console.log(baseUrl);
           	    $http.get(baseUrl+'?values=' + tags)
           	    	// $http.get('https://predix-seed.run.aws-usw02-pr.ice.predix.io/api/view-service/decks/tags?values=' + tags)
                    .then(function (res) {
                        deferred.resolve(res.data);
                    },
                    function () {
                        deferred.reject('Error fetching decks with tags ' + tags);
                    });
                //deferred.resolve(data);
                return deferred.promise;
            },
            getUrlForFetchingCardsForDeckId: function(deckId) {
            	 var baseUrl = '/sample-data';
            	 return  baseUrl + '/' + deckId + '.json?filter[include][cards]';
            	 //{"id":"1","title":"Overview","slug":"px-deck","cardOrder":null,"createTimeStamp":"2015-11-24T23:02:53.838Z","tags":[{"id":"1","value":"parent"}],"cards":[{"id":"2","title":"widgets card","slug":"widgets-card","attributes":{},"createTimeStamp":"2015-11-24T23:02:53.816Z","tags":[]},{"id":"3","title":"gist card","slug":"gist-card","attributes":{},"createTimeStamp":"2015-11-24T23:02:53.816Z","tags":[]}]}
                //return '/api/view-service/decks/' + deckId + '?filter[include][cards]';
            }
        };
    }]);
});
