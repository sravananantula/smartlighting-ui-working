define(['angular', './sample-module'], function (angular, controllers) {
    'use strict';
    // Controller definition
    controllers.controller('datatableCon', ['$scope', '$log', 'PredixAssetService', 'PredixViewService', '$http', function ($scope, $log, PredixAssetService, PredixViewService, $http) {

        //         $http.get('http://3.96.150.236/RestService/IHistorianService.svc/GetFleetDate').success(function(data) {
        //              $scope.user1 = data;
        //              alert( $scope.user1);
        //         });

        //                $.ajax({
        //                    type: "GET",
        //                    url: 'http://3.96.150.236/RestService/IHistorianService.svc/GetFleetDate',
        //                    success: function (data) {
        //                       
        //                    }
        //                });

        var JSONObj = [{ "id": 2, "name": "An ice sculpture", "price": 12.50 }, { "id": 3, "name": "A blue mouse", "price": 25.50}]
        $scope.user1 = JSONObj;
        
        debugger;

        //http://3.96.150.236/RestService/IHistorianService.svc/GetFleetDate
        var att=[];
        att =[
		
                    [1252731600000, 24],
                    [1252818000000, 48],
                    [1252904400000, 72],
                    [1252990800000, 96],
                    [1253077200000, 120],
                    [1253163600000, 144]
                ];

        document.querySelector('#my-series').seriesObj = {
            myData: att

        };
    } ]);
});


